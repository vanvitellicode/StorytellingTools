export default {
    id: 'mirador',
       displayAllAnnotations: false,
       window: {
          sideBarOpenByDefault: sidebar,
          imageToolsEnabled: true,
          imageToolsOpen: false,
          modelViewerBackground :"#000000", 
          modelViewerProgressHeight:"5px",
          modelViewerProgressColor:"#fc03be",
          modelViewerAutoRotate: true,
      },
  windows: wins,
  catalog: mans
  };